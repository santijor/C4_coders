//
// Created by cguxt on 28/06/2025.
//

#ifndef EXPORTAR_H
#define EXPORTAR_H
#include "../cursada.h"
#include "../estudiante.h"
#include "../materia.h"

void exportar_cursadas_CSV(Nodo *lista);
void exportar_estudiantes_CSV(Nodo *lista);
void exportar_materias_CSV(Nodo *lista);


#endif //EXPORTAR_H
